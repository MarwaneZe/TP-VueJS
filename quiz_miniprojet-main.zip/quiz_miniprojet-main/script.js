const questionElement = document.getElementById('question');
const answerButtons = document.getElementById('answer-buttons');
const nextButton = document.getElementById('next-btn');
const quizContainer = document.getElementById('quiz-container');
const configContainer = document.getElementById('config-container');
const startBtn = document.getElementById('start-btn');

const amountInput = document.getElementById('amount');
const categorySelect = document.getElementById('category');
const difficultySelect = document.getElementById('difficulty');
const typeSelect = document.getElementById('type');

let currentQuestionIndex = 0;
let score = 0;
let questions = [];


async function fetchQuestions() {
    const amount = amountInput.value;
    const category = categorySelect.value;
    const difficulty = difficultySelect.value;
    const type = typeSelect.value;

    let apiUrl = `https://opentdb.com/api.php?amount=${amount}`;
    if (category) apiUrl += `&category=${category}`;
    if (difficulty) apiUrl += `&difficulty=${difficulty}`;
    if (type) apiUrl += `&type=${type}`;

    try {
        const response = await fetch(apiUrl);
        const data = await response.json();

        questions = data.results.map(q => {
            const allAnswers = [...q.incorrect_answers];
            const correctIndex = Math.floor(Math.random() * (allAnswers.length + 1));
            allAnswers.splice(correctIndex, 0, q.correct_answer);

            return {
                question: decodeHTML(q.question),
                answers: allAnswers.map(ans => ({
                    text: decodeHTML(ans),
                    correct: ans === q.correct_answer
                }))
            };
        });

        startQuiz();
    } catch (error) {
        alert("Error fetching quiz questions. Please try again!");
        console.error(error);
    }
}

function decodeHTML(text) {
    const txt = document.createElement("textarea");
    txt.innerHTML = text;
    return txt.value;
}

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";

    configContainer.style.display = "none";
    quizContainer.style.display = "block";

    showQuestions();
}

function showQuestions() {
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question;

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
        if (answer.correct) {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
    });
}

function resetState() {
    nextButton.style.display = "none";
    while (answerButtons.firstChild) {
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function selectAnswer(e) {
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    if (isCorrect) {
        selectedBtn.classList.add("correct");
        score++;
    } else {
        selectedBtn.classList.add("incorrect");
    }

    Array.from(answerButtons.children).forEach(button => {
        if (button.dataset.correct === "true") {
            button.classList.add("correct");
        }
        button.disabled = true;
    });

    nextButton.style.display = "block";
}

function showScore() {
    resetState();
    questionElement.innerHTML = `🎉 You scored ${score} out of ${questions.length}!`;
    nextButton.innerHTML = "Play again";
    nextButton.style.display = "block";
}

function handleNextButton() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestions();
    } else {
        showScore();
    }
}


nextButton.addEventListener("click", () => {
    if (currentQuestionIndex < questions.length) {
        handleNextButton();
    } else {
        configContainer.style.display = "block";
        quizContainer.style.display = "none";
    }
});

startBtn.addEventListener("click", (e) => {
    e.preventDefault(); // prevent form reload
    fetchQuestions();
});
